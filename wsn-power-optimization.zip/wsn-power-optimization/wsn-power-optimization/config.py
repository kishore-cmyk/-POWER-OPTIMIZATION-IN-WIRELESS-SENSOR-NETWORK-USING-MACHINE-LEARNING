# Simulation parameters
SIMULATION_CONFIG = {
    'num_nodes': 30,
    'area_size': 100,
    'initial_energy': 50,
    'base_station_position': (50, 50),
    'simulation_steps': 100,
    'training_steps': 50,
}

# ML model parameters
ML_CONFIG = {
    'model_type': 'random_forest',
    'test_size': 0.2,
    'random_state': 42,
}

# Energy model parameters
ENERGY_CONFIG = {
    'tx_energy_coeff': 0.01,
    'rx_energy_coeff': 0.005,
    'idle_energy': 0.001,
    'sleep_energy': 0.0001,
}
