import numpy as np
from config import ENERGY_CONFIG

class SimpleWSNSimulator:
    """Simple WSN simulator for beginners"""
    
    def __init__(self, num_nodes=30, area_size=100, initial_energy=50):
        self.num_nodes = num_nodes
        self.area_size = area_size
        self.initial_energy = initial_energy
        self.base_station = (area_size/2, area_size/2)  # Define this FIRST
        self.nodes = self._initialize_nodes()  # Then call this
        self.time_step = 0
        self.history = []
        
    def _initialize_nodes(self):
        nodes = {}
        for i in range(self.num_nodes):
            x = np.random.uniform(0, self.area_size)
            y = np.random.uniform(0, self.area_size)
            energy = self.initial_energy * np.random.uniform(0.8, 1.2)
            
            nodes[i] = {
                'position': (x, y),
                'energy': energy,
                'alive': True,
                'data_generated': 0,
                'sleep_mode': False,
                'distance_to_bs': self._calculate_distance((x, y), self.base_station)
            }
        return nodes
    
    def _calculate_distance(self, pos1, pos2):
        return np.sqrt((pos1[0]-pos2[0])**2 + (pos1[1]-pos2[1])**2)
    
    def generate_data(self):
        for node_id, node in self.nodes.items():
            if node['alive'] and not node['sleep_mode']:
                if np.random.random() < 0.1:
                    node['data_generated'] += np.random.randint(1, 4)
    
    def calculate_energy_consumption(self, distance, packet_size=1):
        tx_energy = ENERGY_CONFIG['tx_energy_coeff'] * (distance ** 2) * packet_size
        rx_energy = ENERGY_CONFIG['rx_energy_coeff'] * packet_size
        return tx_energy, rx_energy
    
    def simulate_communication(self):
        for node_id, node in self.nodes.items():
            if node['alive'] and not node['sleep_mode'] and node['data_generated'] > 0:
                distance_to_bs = self._calculate_distance(node['position'], self.base_station)
                tx_energy, _ = self.calculate_energy_consumption(distance_to_bs, node['data_generated'])
                node['energy'] -= tx_energy
                node['data_generated'] = 0
                
                if node['energy'] <= 0:
                    node['alive'] = False
                    node['energy'] = 0
    
    def update_idle_energy(self):
        for node_id, node in self.nodes.items():
            if node['alive']:
                if node['sleep_mode']:
                    node['energy'] -= ENERGY_CONFIG['sleep_energy']
                else:
                    node['energy'] -= ENERGY_CONFIG['idle_energy']
                
                if node['energy'] <= 0:
                    node['alive'] = False
                    node['energy'] = 0
    
    def step(self):
        self.time_step += 1
        self.generate_data()
        self.simulate_communication()
        self.update_idle_energy()
        
        alive_nodes = sum(1 for node in self.nodes.values() if node['alive'])
        total_energy = sum(node['energy'] for node in self.nodes.values())
        
        self.history.append({
            'time': self.time_step,
            'alive_nodes': alive_nodes,
            'total_energy': total_energy
        })
        
        return alive_nodes
    
    def get_features(self):
        features = []
        for node_id, node in self.nodes.items():
            if node['alive']:
                features.append([
                    node_id,
                    node['position'][0],
                    node['position'][1],
                    node['energy'],
                    node['distance_to_bs'],
                    node['data_generated'],
                    1 if node['sleep_mode'] else 0
                ])
        return np.array(features)