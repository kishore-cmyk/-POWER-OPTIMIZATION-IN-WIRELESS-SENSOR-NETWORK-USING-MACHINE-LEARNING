import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import os
from wsn_simulator import SimpleWSNSimulator
from power_optimizer import SimplePowerOptimizer

def generate_training_data(simulator, steps=50):
    X, y = [], []
    
    for _ in range(steps):
        features = simulator.get_features()
        if len(features) > 0:
            current_energies = features[:, 3].copy()
            simulator.step()
            new_features = simulator.get_features()
            
            if len(new_features) > 0:
                # Match nodes by ID
                current_nodes = {int(row[0]): i for i, row in enumerate(features)}
                new_nodes = {int(row[0]): i for i, row in enumerate(new_features)}
                common_nodes = set(current_nodes.keys()) & set(new_nodes.keys())
                
                for node_id in common_nodes:
                    current_idx = current_nodes[node_id]
                    new_idx = new_nodes[node_id]
                    energy_consumption = features[current_idx, 3] - new_features[new_idx, 3]
                    
                    if energy_consumption > 0:
                        X.append(features[current_idx, 1:])  # Skip node_id
                        y.append(energy_consumption)
    
    return np.array(X), np.array(y)

def calculate_network_lifetime(alive_history, threshold=0.5):
    initial_nodes = alive_history[0]
    threshold_nodes = initial_nodes * threshold
    
    for step, alive_count in enumerate(alive_history):
        if alive_count < threshold_nodes:
            return step
    
    return len(alive_history)

def run_simulation():
    print("WSN Power Optimization using Machine Learning")
    print("=" * 50)
    
    # Initialize components
    simulator = SimpleWSNSimulator(num_nodes=30, area_size=100, initial_energy=50)
    optimizer = SimplePowerOptimizer()
    
    # Phase 1: Training
    print("1. Generating training data...")
    X_train, y_train = generate_training_data(simulator, steps=50)
    
    if len(X_train) > 0:
        feature_names = ['pos_x', 'pos_y', 'energy', 'dist_to_bs', 'data_generated', 'sleep_mode']
        df_train = pd.DataFrame(X_train, columns=feature_names)
        df_train['energy_consumption'] = y_train
        df_train.to_csv('data/training_data.csv', index=False)
        print(f"Training data saved: {len(X_train)} samples")
    else:
        print("No training data generated! Using simple optimization instead.")
        return run_simple_simulation()
    
    # Phase 2: Model training
    print("2. Training ML model...")
    try:
        mse = optimizer.train_energy_model(X_train, y_train)
        optimizer.save_model('models/energy_model.pkl')
    except Exception as e:
        print(f"Error in model training: {e}")
        return run_simple_simulation()
    
    # Phase 3: Simulation
    print("3. Running optimized simulation...")
    simulator_opt = SimpleWSNSimulator(num_nodes=30, area_size=100, initial_energy=50)
    simulator_base = SimpleWSNSimulator(num_nodes=30, area_size=100, initial_energy=50)
    
    alive_opt, alive_base = [], []
    
    for i in range(100):
        if i % 5 == 0:
            optimizer.optimize_sleep_schedule(simulator_opt)
        
        alive_opt.append(simulator_opt.step())
        alive_base.append(simulator_base.step())
        
        if i % 20 == 0:
            print(f"Step {i}: Opt {alive_opt[-1]} alive, Base {alive_base[-1]} alive")
    
    # Phase 4: Results
    print("4. Analyzing results...")
    lifetime_opt = calculate_network_lifetime(alive_opt)
    lifetime_base = calculate_network_lifetime(alive_base)
    
    if lifetime_base > 0:
        improvement = ((lifetime_opt / lifetime_base) - 1) * 100
    else:
        improvement = 0
    
    print("\n5. Final Results:")
    print("=" * 40)
    print(f"Optimized network lifetime: {lifetime_opt} steps")
    print(f"Baseline network lifetime: {lifetime_base} steps")
    print(f"Improvement: {improvement:.2f}%")
    
    # Plot results
    plt.figure(figsize=(10, 6))
    plt.plot(alive_opt, 'b-', label='With ML Optimization', linewidth=2)
    plt.plot(alive_base, 'r-', label='Baseline', linewidth=2)
    plt.xlabel('Time Steps')
    plt.ylabel('Alive Nodes')
    plt.title('WSN Lifetime Comparison')
    plt.legend()
    plt.grid(True, alpha=0.3)
    plt.savefig('results/lifetime_comparison.png', dpi=300, bbox_inches='tight')
    plt.show()
    
    if improvement >= 30:
        print("✅ SUCCESS: Target achieved (30%+ improvement)!")
    else:
        print("❌ Target not achieved")
    
    return improvement

def run_simple_simulation():
    """Fallback simple simulation without ML"""
    print("Running simple simulation without ML...")
    
    simulator_opt = SimpleWSNSimulator(num_nodes=30, area_size=100, initial_energy=50)
    simulator_base = SimpleWSNSimulator(num_nodes=30, area_size=100, initial_energy=50)
    
    alive_opt, alive_base = [], []
    
    for i in range(100):
        # Simple sleep scheduling for optimized version
        if i % 5 == 0:
            energies = [node['energy'] for node in simulator_opt.nodes.values() if node['alive']]
            if energies:
                avg_energy = np.mean(energies)
                for node_id, node in simulator_opt.nodes.items():
                    if node['alive']:
                        node['sleep_mode'] = node['energy'] < avg_energy * 0.8
        
        alive_opt.append(simulator_opt.step())
        alive_base.append(simulator_base.step())
        
        if i % 20 == 0:
            print(f"Step {i}: Opt {alive_opt[-1]} alive, Base {alive_base[-1]} alive")
    
    lifetime_opt = calculate_network_lifetime(alive_opt)
    lifetime_base = calculate_network_lifetime(alive_base)
    
    if lifetime_base > 0:
        improvement = ((lifetime_opt / lifetime_base) - 1) * 100
    else:
        improvement = 0
    
    print(f"Improvement: {improvement:.2f}%")
    return improvement

if __name__ == "__main__":
    # Create directories
    os.makedirs('data', exist_ok=True)
    os.makedirs('models', exist_ok=True)
    os.makedirs('results', exist_ok=True)
    
    # Run simulation
    improvement = run_simulation()