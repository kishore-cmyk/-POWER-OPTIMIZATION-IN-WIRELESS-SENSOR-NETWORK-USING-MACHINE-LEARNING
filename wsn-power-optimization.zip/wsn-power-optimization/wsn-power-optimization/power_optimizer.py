from sklearn.ensemble import RandomForestRegressor
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error
import numpy as np
import joblib

class SimplePowerOptimizer:
    """Simple ML-based power optimizer"""
    
    def __init__(self):
        self.energy_model = RandomForestRegressor(n_estimators=10, random_state=42)
        self.is_trained = False
        
    def train_energy_model(self, X, y):
        if len(X) == 0 or len(y) == 0:
            raise ValueError("No data to train on")
            
        X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        self.energy_model.fit(X_train, y_train)
        
        y_pred = self.energy_model.predict(X_test)
        mse = mean_squared_error(y_test, y_pred)
        
        print(f"Model trained. MSE: {mse:.4f}")
        print(f"Training samples: {len(X_train)}, Test samples: {len(X_test)}")
        
        self.is_trained = True
        return mse
    
    def predict_energy_consumption(self, features):
        if not self.is_trained:
            raise ValueError("Model not trained yet")
        
        if len(features) == 0:
            return np.array([])
            
        # Use only feature columns (skip node_id)
        X = features[:, 1:] if features.shape[1] > 1 else features
        return self.energy_model.predict(X)
    
    def optimize_sleep_schedule(self, simulator):
        features = simulator.get_features()
        if len(features) == 0:
            return
        
        try:
            predicted_consumption = self.predict_energy_consumption(features)
            current_energies = features[:, 3]
            
            if len(predicted_consumption) > 0:
                avg_energy = np.mean(current_energies)
                avg_consumption = np.mean(predicted_consumption)
                
                for i, node_id in enumerate(features[:, 0].astype(int)):
                    node = simulator.nodes[node_id]
                    
                    if node['energy'] < 5:
                        node['sleep_mode'] = True
                        continue
                    
                    low_energy = node['energy'] < avg_energy * 0.7
                    high_consumption = predicted_consumption[i] > avg_consumption * 1.3
                    
                    if low_energy and high_consumption:
                        node['sleep_mode'] = True
                    elif node['energy'] > avg_energy * 1.5:
                        node['sleep_mode'] = False
                    else:
                        node['sleep_mode'] = np.random.random() < 0.3
                        
        except Exception as e:
            print(f"Error in sleep scheduling: {e}")
    
    def save_model(self, filename):
        if self.is_trained:
            joblib.dump(self.energy_model, filename)
            print(f"Model saved to {filename}")
    
    def load_model(self, filename):
        self.energy_model = joblib.load(filename)
        self.is_trained = True
        print(f"Model loaded from {filename}")